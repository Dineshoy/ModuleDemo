import { Component, OnInit} from '@angular/core';

@Component({
  selector: 'pm-products',
  templateUrl: './Product-list.component.html',
  styleUrls:['./Product-list.component.css']
})
export class ProductListComponent implements OnInit{    
       listFilter: string='cart'; 
    products: any[] = [
{
         
    "productId": 2,
    "productName": "Garden Cart",
    "productCode": "GDN-0023",
    "releaseDate": "March 18,2016",
    "description": "15 gallon capacity rolling garden cart",
    "price": 32.99,
    "starRating": 4.2,
    "imageUrl": "https://openclipart.org/image/300px/svg_to_png/58471/garden_cart.png"
    },
{
    "productId": 5,
    "productName": "Hammer",
    "productCode": "TBX-0048",
    "releaseDate": "March 21,2016",
    "description": "curved claw steel hammer",
    "price": 8.9,
    "starRating": 4.8,
    "imageUrl": "https://openclipart.org/image/300px/svg_to_png/73/rejon_Hammer.png"
    }
];
    ngOnInit():void{
        console.log("this is called");
     }
    toggleImage(id:number,name:string,salary:number,department:string):void{
       alert("Id is:"+id+ "Name is:"+name +"Salary is:"+salary+ "Department is:"+department)
    }
    }
